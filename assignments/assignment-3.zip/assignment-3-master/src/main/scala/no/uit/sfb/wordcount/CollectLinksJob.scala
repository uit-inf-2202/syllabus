package no.uit.sfb.wordcount

//Students : Code your collect-links program here
